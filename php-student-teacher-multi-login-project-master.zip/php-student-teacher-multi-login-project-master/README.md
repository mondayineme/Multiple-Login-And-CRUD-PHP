# php-student-teacher-multi-login-project
php-student-teacher-multi-login-project
In This Project Two Login Works
1. For Teacher  -> Who add Students and Their Result also Edit the Results
2. For Student -> Who can login and View Their Result

Tutorial Cover : <br>
How to Create Multi login System in PHP<br>
How to Create a Form in PHP<br>
How to use Session<br>
How to Authorize User to Access Specific Pages<br>
